package com.examcomplexivo.subastainversaservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubastaInversaServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
