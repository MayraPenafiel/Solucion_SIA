package com.examcomplexivo.subastainversaservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubastaInversaServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubastaInversaServicesApplication.class, args);
	}

}
